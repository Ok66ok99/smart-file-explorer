import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:archive/archive_io.dart';
import 'package:open_filex/open_filex.dart';

void main() => runApp(const ExplorerApp());

class ExplorerApp extends StatelessWidget {
  const ExplorerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'مستكشف الملفات الذكي',
    theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
    home: const Directionality(textDirection: TextDirection.rtl, child: ExplorerHome()),
  );
}

class ExplorerHome extends StatefulWidget {
  const ExplorerHome({super.key});
  @override
  State<ExplorerHome> createState() => _ExplorerHomeState();
}

class _ExplorerHomeState extends State<ExplorerHome> {
  final List<File> files = [];
  final Set<String> selected = {};
  bool oldestFirst = true;
  bool loading = false;
  String status = 'اختر ملفات من جهازك لعرضها وتحليلها';
  final Map<String, FileStat> stats = {};

  Future<void> pick() async {
    setState(() => loading = true);
    try {
      final result = await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.any, withData: false);
      if (result == null) return;
      int added = 0;
      for (final item in result.files) {
        if (item.path == null) continue;
        final f = File(item.path!);
        if (!await f.exists()) continue;
        if (files.any((e) => e.path == f.path)) continue;
        files.add(f);
        stats[f.path] = await f.stat();
        added++;
      }
      sortFiles();
      status = 'تمت إضافة $added ملفات. الملفات التي لا يسمح النظام بقراءتها لن تظهر.';
    } catch (e) {
      status = 'تعذر اختيار الملفات: $e';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void sortFiles() {
    files.sort((a, b) {
      final ad = stats[a.path]?.modified ?? DateTime.fromMillisecondsSinceEpoch(0);
      final bd = stats[b.path]?.modified ?? DateTime.fromMillisecondsSinceEpoch(0);
      return oldestFirst ? ad.compareTo(bd) : bd.compareTo(ad);
    });
  }

  String size(int bytes) {
    if (bytes >= 1073741824) return '${(bytes / 1073741824).toStringAsFixed(2)} GB';
    if (bytes >= 1048576) return '${(bytes / 1048576).toStringAsFixed(2)} MB';
    return '${(bytes / 1024).toStringAsFixed(1)} KB';
  }

  String date(DateTime dt) => '${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}';

  Future<void> inspect(File file) async {
    final ext = p.extension(file.path).toLowerCase();
    String details = '';
    try {
      final st = await file.stat();
      details = 'الاسم: ${p.basename(file.path)}\nالحجم: ${size(st.size)}\nآخر تعديل: ${date(st.modified)}\nالمسار: ${file.path}\n\n';
      if (ext == '.pdf') {
        final bytes = await file.readAsBytes();
        final doc = PdfDocument(inputBytes: bytes);
        try {
          final count = doc.pages.count;
          final raw = PdfTextExtractor(doc).extractText();
          final text = raw.replaceAll(RegExp(r'\s+'), ' ').trim();
          final sentences = text.split(RegExp(r'(?<=[.!؟])\s+')).where((s) => s.trim().length > 35).take(5).join(' ');
          details += 'عدد الصفحات: $count\n\nملخص مقتطفات من النص (ليس تلخيصًا بالذكاء الاصطناعي):\n${sentences.isNotEmpty ? sentences : (text.isEmpty ? 'لم يتم استخراج نص. قد يكون المستند صورًا ممسوحة ضوئيًا.' : text.substring(0, text.length > 650 ? 650 : text.length))}\n';
        } finally { doc.dispose(); }
      } else if (ext == '.zip') {
        final input = InputFileStream(file.path);
        try {
          final archive = ZipDecoder().decodeStream(input);
          final entries = archive.files;
          details += 'عدد عناصر الأرشيف: ${entries.length}\n\n${entries.take(60).map((e) => '${e.name} (${size(e.size)})').join('\n')}';
          if (entries.length > 60) details += '\n... وعناصر إضافية';
        } finally { input.close(); }
      } else {
        details += 'لا يتوفر تحليل محتوى محلي لهذا النوع في هذه النسخة. يمكنك فتح الملف بتطبيق مناسب.';
      }
    } catch (e) {
      details += '\nتعذر تحليل المحتوى: $e';
    }
    if (!mounted) return;
    showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('معاينة معلومات الملف'),
      content: SizedBox(width: double.maxFinite, child: SingleChildScrollView(child: SelectableText(details))),
      actions: [TextButton(onPressed: () => OpenFilex.open(file.path), child: const Text('فتح الملف')),
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق'))],
    ));
  }

  Future<void> removeSelected() async {
    if (selected.isEmpty) return;
    final bytes = files.where((f) => selected.contains(f.path)).fold<int>(0, (sum, f) => sum + (stats[f.path]?.size ?? 0));
    final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('تأكيد حذف الملفات'),
      content: Text('سيُحذف ${selected.length} ملفًا (${size(bytes)}) نهائيًا من المسارات المتاحة. لا توجد سلة استعادة داخل التطبيق. هل أنت متأكد؟'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف نهائي'))],
    ));
    if (confirmed != true) return;
    int removed = 0;
    int failed = 0;
    for (final file in files.where((f) => selected.contains(f.path)).toList()) {
      try {
        await file.delete();
        files.remove(file);
        stats.remove(file.path);
        removed++;
      } catch (_) { failed++; }
    }
    selected.clear();
    if (mounted) setState(() => status = 'حُذف $removed ملفًا؛ تعذر حذف $failed ملفًا بسبب صلاحيات النظام أو أخطاء أخرى.');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مستكشف الملفات الذكي')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        FilledButton.icon(onPressed: loading ? null : pick, icon: const Icon(Icons.folder_open), label: Text(loading ? 'جارٍ التحميل' : 'اختيار ملفات للفحص')),
        SwitchListTile(title: const Text('الترتيب من الأقدم إلى الأحدث'), value: oldestFirst, onChanged: (v) => setState(() { oldestFirst = v; sortFiles(); })),
        Text(status, style: Theme.of(context).textTheme.bodySmall),
        Text('الملفات: ${files.length} | المحددة: ${selected.length}', style: Theme.of(context).textTheme.titleSmall),
      ])),
      Expanded(child: files.isEmpty ? const Center(child: Text('لم تُحدد ملفات بعد')) : ListView.builder(itemCount: files.length, itemBuilder: (context, index) {
        final f = files[index];
        final st = stats[f.path];
        return ListTile(
          leading: Checkbox(value: selected.contains(f.path), onChanged: (v) => setState(() { if (v == true) { selected.add(f.path); } else { selected.remove(f.path); } })),
          title: Text(p.basename(f.path), maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${st == null ? '' : size(st.size)} · ${st == null ? '' : date(st.modified)}'),
          trailing: IconButton(tooltip: 'معلومات الملف', icon: const Icon(Icons.visibility_outlined), onPressed: () => inspect(f)),
        );
      })),
    ]),
    bottomNavigationBar: SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: FilledButton.icon(
      onPressed: selected.isEmpty ? null : removeSelected, icon: const Icon(Icons.delete_outline), label: const Text('مراجعة حذف الملفات المحددة')))),
  );
}
