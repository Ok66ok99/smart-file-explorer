Smart File Explorer - full Flutter source and GitHub Actions workflow. Upload the extracted folders to the repository root. Build is unverified.
